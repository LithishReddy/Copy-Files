"""
Tailwind UI Components code snippets RAG
"""