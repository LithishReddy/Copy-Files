"""
Stack overflow query searcher and retrieval
"""